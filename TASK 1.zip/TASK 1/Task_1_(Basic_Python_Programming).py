#!/usr/bin/env python
# coding: utf-8

# # Q1.Say "Hello, World!" With Python

# In[1]:


string = "Hello, World!"
print(string)


# # Q 2 Task
# Given an integer, , perform the following conditional actions:
# 
# If  is odd, print Weird
# If  is even and in the inclusive range of  to , print Not Weird
# If  is even and in the inclusive range of  to , print Weird
# If  is even and greater than , print Not Weird
# Input Format
# 
# A single line containing a positive integer, .

# In[2]:


import math
import os
import random
import re
import sys



if __name__ == '__main__':
    n = int(input().strip())
if n%2==1:
    print("Weird")
elif n % 2 == 0 and 2 <= n <= 5:
    print("Not Weird")
elif n % 2 == 0 and 6 <= n <= 20:
    print("Weird")
else:
    print("Not Weird")


# # Q3.Task
# The provided code stub reads two integers from STDIN, and
# 
# . Add code to print three lines where:
# 
#     The first line contains the sum of the two numbers.
#     The second line contains the difference of the two numbers (first - second).
#     The third line contains the product of the two numbers.
# 

# In[3]:


if __name__ == '__main__':
    a = int(input())
    b = int(input())
    add = a + b
    sub = a - b
    po = a * b
    print(add)
    print(sub)
    print(po)


# # Q4.Task
# The provided code stub reads two integers, and
# 
# , from STDIN.
# 
# Add logic to print two lines. The first line should contain the result of integer division,
# // . The second line should contain the result of float division, /
# 
# .
# 
# No rounding or formatting is necessary.

# In[4]:


if __name__ == '__main__':
    a = int(input())
    b = int(input())
    c = a//b
    d = a/b
    print(c)
    print(d)


# # Q5.Task
# The provided code stub reads and integer, , from STDIN. For all non-negative integers , print . 

# In[5]:


if __name__ == '__main__':
    n = int(input())
    for i in range(0,n):
        print (i**2)


# # Q6.An extra day is added to the calendar almost every four years as February 29, and the day is called a leap day. It corrects the calendar for the fact that our planet takes approximately 365.25 days to orbit the sun. A leap year contains a leap day.

# In[6]:


def is_leap(year):
    leap = False
    
    
    if (year%400==0):
        return True
    
    if year%100==0:
        return False        
    if (year%4==0):
        return True    
    
    return leap

year = int(input())
print(is_leap(year))


# # Q7.The included code stub will read an integer, , from STDIN.

# In[9]:


if __name__ == '__main__':
     print(*range(1, int(input())+1), sep='')


# In[ ]:




